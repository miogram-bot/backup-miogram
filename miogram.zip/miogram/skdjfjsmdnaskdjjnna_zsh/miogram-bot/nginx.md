# Nginx Reverse Proxy — Miogram Bot Fleet

Complete, copy-paste ready configuration for routing Telegram webhooks,
payment callbacks and static files to the fleet instances.

**Before deploying:** replace every occurrence of `yourdomain.com` with your
real domain. Port mapping matches `docker-compose.yml`:

| Path | Upstream | Instance |
|---|---|---|
| `/bot/main` | 127.0.0.1:8080 | main bot |
| `/bot/shard1` … `/bot/shard5` | 127.0.0.1:8081 … 8085 | helper bots |
| `/pay/` | 127.0.0.1:8080 (main) | payment gateway callbacks |
| `/files/` | 127.0.0.1:8080 (main) | static bot assets |

Notes:

- Nginx forwards request headers (including Telegram's
  `X-Telegram-Bot-Api-Secret-Token`) to upstreams automatically; no explicit
  directive is needed for them.
- The app reads the client IP from `X-Forwarded-For` (`clientIP()` in
  `cmd/miogram/main.go`) when `VERIFY_TELEGRAM_IP=true`, so only your nginx
  may talk to the app ports — do not expose 808x publicly.
- Certificates use standard Let's Encrypt live paths; obtain them with
  `certbot --nginx -d yourdomain.com` or webroot, and certbot will reload
  nginx on renewal.

```nginx
# /etc/nginx/sites-available/miogram
# symlink to: /etc/nginx/sites-enabled/miogram

# ------------------------------------------------------------------
# HTTP :80 — everything is redirected permanently to HTTPS.
# ACME http-01 challenges stay on port 80 so certbot can renew.
# ------------------------------------------------------------------
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com;          # <-- replace with real domain

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

# ------------------------------------------------------------------
# HTTPS :443 — main entrypoint for all bots.
# ------------------------------------------------------------------
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;                            # nginx >= 1.25 syntax.
                                         # For nginx < 1.25 use:
                                         #   listen 443 ssl http2;
    server_name yourdomain.com;          # <-- replace with real domain

    # --- TLS (Let's Encrypt) ---------------------------------------
    ssl_certificate     /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    ssl_protocols        TLSv1.2 TLSv1.3;
    ssl_ciphers          ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
    ssl_prefer_server_ciphers off;

    ssl_session_cache    shared:SSL:10m;
    ssl_session_timeout  1d;
    ssl_session_tickets  off;

    # Optional but recommended once the site is stable:
    # add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Media uploads (photos/videos sent through the bot flows that hit the
    # app directly) need headroom above Telegram's ~50MB file cap.
    client_max_body_size 20m;

    # --- Shared proxy behaviour -------------------------------------
    # Real client IP reaches the app via X-Forwarded-For, which the bot uses
    # for its Telegram IP allowlist (VERIFY_TELEGRAM_IP=true).
    proxy_http_version                 1.1;
    proxy_set_header Host              $host;
    proxy_set_header X-Real-IP         $remote_addr;
    proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header Connection        "";

    # Webhooks are small POSTs answered in milliseconds — fail fast so
    # Telegram retries instead of queuing on a dead instance.
    proxy_connect_timeout              5s;
    proxy_send_timeout                 15s;
    proxy_read_timeout                 15s;

    # -----------------------------------------------------------------
    # Telegram webhooks — one location per fleet instance.
    # WEBHOOK_PATH in each .env must match these exact prefixes:
    #   main   -> /bot/main    (port 8080)
    #   shardN -> /bot/shardN  (ports 8081..8085)
    # -----------------------------------------------------------------
    location /bot/main {
        proxy_pass http://127.0.0.1:8080;
    }

    location /bot/shard1 {
        proxy_pass http://127.0.0.1:8081;
    }

    location /bot/shard2 {
        proxy_pass http://127.0.0.1:8082;
    }

    location /bot/shard3 {
        proxy_pass http://127.0.0.1:8083;
    }

    location /bot/shard4 {
        proxy_pass http://127.0.0.1:8084;
    }

    location /bot/shard5 {
        proxy_pass http://127.0.0.1:8085;
    }

    # -----------------------------------------------------------------
    # Payment gateway callbacks (Zarinpal return flow) are handled by the
    # main instance: /pay/request.php and /pay/verify.php
    # -----------------------------------------------------------------
    location /pay/ {
        proxy_pass http://127.0.0.1:8080;
    }

    # -----------------------------------------------------------------
    # Static bot assets (help images etc.) served from FILES_DIR by the
    # main instance under /files/.
    # -----------------------------------------------------------------
    location /files/ {
        proxy_pass http://127.0.0.1:8080;
        # Assets are immutable content-addressed images — cache hard.
        expires 7d;
        add_header Cache-Control "public, max-age=604800, immutable";
    }

    # -----------------------------------------------------------------
    # Health probe for load balancers / uptime monitors.
    # -----------------------------------------------------------------
    location = /healthz {
        proxy_pass http://127.0.0.1:8080;
        access_log off;
    }
}
```

## Deployment checklist

1. Replace `yourdomain.com` everywhere (both server blocks + certificate paths).
2. `sudo ln -s /etc/nginx/sites-available/miogram /etc/nginx/sites-enabled/`
3. Obtain/renew certificates: `sudo certbot --nginx -d yourdomain.com`
4. Validate before reloading: `sudo nginx -t && sudo systemctl reload nginx`
5. Ensure ports **8080–8085 are bound to localhost only** (compose already
   maps them on the host; firewall or remove `ports:` publishing if the host
   is public).
6. Set a strong `WEBHOOK_SECRET` in each `.env.*` — Telegram sends it in
   `X-Telegram-Bot-Api-Secret-Token`, which this proxy passes through
   untouched and the app verifies (main.go webhook handler).
