# Miogram Go Bot

نسخه Go ربات چت ناشناس با معماری webhook -> Redis queue -> worker.

## اجرا

1. فایل `.env.example` را به `.env` تبدیل کنید و مقدارهای `BOT_TOKEN`, `MERCHANT_ID` و `WORKER_COUNT` را تنظیم کنید. برای اجرای production مقدار `PUBLIC_BASE_URL` هم لازم است؛ در حالت `IS_DEVELOP=true` این مقدار از تونل ساخته می‌شود.
2. سرویس را بالا بیاورید:

```bash
docker compose up -d --build
```

## تست روی localhost

برای تست محلی، در `.env` این مقدار را فعال کنید:

```env
IS_DEVELOP=true
```

در این حالت سرویس با `cloudflared` یک Quick Tunnel عمومی می‌سازد، `PUBLIC_BASE_URL` را با URL موقت `trycloudflare.com` جایگزین می‌کند و webhook تلگرام را روی همان آدرس تنظیم می‌کند. چون درخواست webhook از Cloudflare به برنامه می‌رسد، در حالت توسعه `VERIFY_TELEGRAM_IP` به صورت خودکار خاموش می‌شود.

Quick Tunnel فقط برای توسعه و تست محلی مناسب است؛ برای production از دامنه و تونل/زیرساخت پایدار استفاده کنید.

اگر روی Docker اجرا می‌کنید، `cloudflared` داخل image نصب می‌شود. اگر بدون Docker اجرا می‌کنید، `cloudflared` باید در PATH باشد یا مسیر آن را تنظیم کنید:

```env
CLOUDFLARED_PATH=cloudflared
DEVELOP_TUNNEL_TIMEOUT=45s
```

برای ارسال درخواست‌های Bot API از SOCKS5 proxy، مقدار زیر را تنظیم کنید؛ مقدار خالی یعنی خاموش:

```env
TELEGRAM_SOCKS5_PROXY=socks5://127.0.0.1:1080
```

3. اگر می‌خواهید سرویس خودش webhook تلگرام را ثبت کند:

```env
SET_WEBHOOK_ON_START=true
WEBHOOK_SECRET=یک-رشته-امن
```

مسیر webhook پیش‌فرض همان مسیر PHP قبلی است:

```text
/bot/user/index.php
```

پرداخت‌ها نیز با مسیرهای قبلی کار می‌کنند:

```text
/pay/request.php?id=...
/pay/verify.php
```

`WORKER_COUNT` تعداد workerهای فعال مصرف‌کننده صف Redis را کنترل می‌کند.

ارسال تمام درخواست‌های Telegram Bot API از صف Redis عبور می‌کند. کنترل نرخ ارسال به‌طور کامل و انحصاری توسط محدودکننده تطبیقی AIMD (بسته fleet) انجام می‌شود که سقف واقعی را از بازخورد خطای ۴۲۹ می‌آموزد؛ محدودکننده ایستای ثابت حذف شده و متغیر محیطی `TELEGRAM_RATE_PER_SECOND` دیگر وجود ندارد.

## ناوگان ربات‌ها (Bot Fleet) و مسیریابی Redis

هر نمونه از برنامه یک ربات را اجرا می‌کند (`BOT_ID`). جدول `user_bot_routing` در Redis آخرین ربات هر کاربر را نگه می‌دارد و تحویل پیام همیشه از طریق **Resolver** در لحظه ارسال انجام می‌شود؛ یعنی دو کاربر روی دو ربات مختلف هم بدون وقفه برای همدیگر پیام می‌فرستند.

اجزای اصلی:

- **Registrar** — با هر آپدیت ورودی، `user_id -> bot_id` را با قانون skip-write ثبت می‌کند (اگر مقدار تغییری نکرده باشد، نوشتن انجام نمی‌شود) و ایندکس معکوس `user_bot_reverse:<bot>` را برای مهاجرت گروهی به‌روز نگه می‌دارد.
- **Resolver** — مقصد هر پیام را از Redis می‌خواند؛ اگر ربات مقصد غیرفعال باشد (heartbeat منقضی یا خارج از پیک)، خودکار به ربات اصلی برمی‌گرداند و کاربر را یک‌بار مطلع می‌کند.
- **Rate Limiter تطبیقی (AIMD)** — پنجره لغزان با بودجه پویا: هنگام 429/flood_wait نصف می‌شود و به مدت `retry_after` توقف می‌کند؛ در حالت آرام هر ثانیه یک واحد افزایش می‌یابد. با `AIMD_MAX=0` هیچ سقف دستی وجود ندارد و سقف واقعی از بازخورد تلگرام کشف می‌شود.
- **Fleet Manager + Leader Election** — رهبری با قفل اجاره‌ای SETNX روی کلید `fleet:leader` انتخاب می‌شود؛ اگر نمونه رهبر از کار بیفتد، اجاره منقضی و نمونه دیگری جایگزین می‌شود. حالت `peak/offpeak` در `fleet:mode` نگه داشته می‌شود و تغییرات از طریق pub/sub (`fleet:control`) هم‌زمان به همه نمونه‌ها اعلام می‌گردد.
- **سیگنال‌های پیک** — سه منبع: فشار 429 (از limiter)، عمق صف خروجی main (`FLEET_PEAK_QUEUE_LEN`)، و بازه زمانی `FLEET_PEAK_HOURS`. بازگشت به off-peak فقط بعد از `FLEET_OFFPEAK_AFTER` آرامش پیوسته انجام می‌شود. با `FLEET_MODE=normal|peak` می‌توان حالت را قفل کرد.
- **Consistent Hashing** — در پیک، کاربرانِ ربات اصلی با حلقه هش ثابت (SHA-256، ۱۶۰ vnode) به helper ثابت خودشان پیشنهاد مهاجرت می‌دهند. لینک پیشنهادی شامل شناسه کاربر است (`?start=migrate_<user_id>`)؛ تأیید با استارت کردن deep-link انجام و بلافاصله در Redis ثبت می‌شود.
- **محافظت از گفتگوی فعال** — کاربری که در حال چت است نه به‌صورت گروهی جابه‌جا می‌شود و نه هنگام ورود به helper غیرفعال bounce می‌شود؛ انتقال او دقیقاً بعد از پایان چت انجام می‌گیرد.
- **صف تحویل در انتظار (Pending)** — اگر ربات مقصد هنوز `/start` کاربر را ندیده و ارسال با 403/chat not found شکست بخورد، پیام همراه شناسه فرستنده در `pending:<bot>:<user>` ذخیره و از طریق ربات اصلی به گیرنده هشدار داده می‌شود. هر نمونه هر دقیقه صف خودش را sweep می‌کند: پیام قدیمی‌تر از `PENDING_FALLBACK` از طریق ربات اصلی تلاش مجدد می‌شود؛ بعد از `PENDING_MAX_ATTEMPTS` شکست، پیام حذف و فرستنده مطلع می‌شود.

در خارج از پیک، leader تمام نگاشت‌های helperها را دسته‌ای به main برمی‌گرداند (به‌جز کاربرانِ در حال چت) و برای MAU یک اعلان «بازگشت به ربات اصلی» برای هر کاربر ارسال می‌کند.

کلیدهای Redis برای مانیتورینگ:

```text
fleet:mode            حالت فعلی ناوگان (peak / offpeak)
fleet:hb:<bot>        heartbeat هر نمونه (TTL دار)
fleet:stats:<bot>     budget limiter، flooded، queue_len، mode، is_leader
fleet:leader          دارنده فعلی رهبری
pending:index:<bot>   کاربرانی که پیام در انتظار دارند
user_bot_reverse:<bot> ایندکس معکوس مسیریابی برای مهاجرت گروهی
```

متغیرهای محیطی مرتبط (نمونه کامل در `.env.main`):

```env
FLEET_MAIN_BOT=main
FLEET_HELPERS=shard1=@miogram_shard1_bot,shard2=@miogram_shard2_bot,shard3=@miogram_shard3_bot
FLEET_MODE=auto
FLEET_PEAK_QUEUE_LEN=200
FLEET_OFFPEAK_AFTER=10m
AIMD_SEED=20
AIMD_MAX=0                   # 0 = بدون سقف دستی
PENDING_FALLBACK=15m
```

## کاربران آزمایشی

جدول `fake_users` هنگام migration خودکار ساخته می‌شود. رکوردها را با نام و `file_id` عکس پروفایل تلگرام وارد کنید؛ جنسیت اختیاری است:

```sql
INSERT INTO fake_users (name, profile_file_id, gender)
VALUES ('نام کاربر', 'AgAC...telegram-file-id...', 'girl');
```

مقدار `gender` می‌تواند `girl`، `boy` یا خالی باشد. سن ۱۴ تا ۳۴، استان، شهر، موقعیت نزدیک و تعداد لایک ۵ تا ۵۰۰ هنگام اتصال ساخته می‌شوند و لازم نیست در این جدول وارد شوند.

گروه ادمین را از پنل تنظیمات ربات ثبت کنید. گزارش‌ها به topicهای ثابت زیر می‌روند: پشتیبانی `44`، تخلفات `45`، فایل‌های گفتگو `49`، پروفایل `50` و فیش پرداخت `84`.
