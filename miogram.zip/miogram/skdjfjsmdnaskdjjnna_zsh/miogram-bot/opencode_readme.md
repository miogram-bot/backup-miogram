# Miogram Fleet — Technical Implementation & Debugging Guide

Audience: developers and AI assistants working on this repository.
Everything below is extracted from the actual code; line numbers are from the
current tree and may drift by a few lines as the code evolves.

---

## 1. Project Overview

Miogram is an anonymous-chat Telegram bot (users are matched and exchange
messages without seeing each other's identity) extended with **horizontal
fleet scaling**:

- **1 main bot + 3 helper bots** (`main`, `shard1..shard3`; `shard4/5` can run
  but are not part of the default fleet set).
- **Redis** is the hot path: per-bot update queues, cross-bot outbound queues,
  user→bot routing table, pending deliveries, fleet state (mode, heartbeats,
  leader lease, stats).
- **PostgreSQL** is the durable layer: users, chats, payments — plus the
  durable half of routing (`users.assigned_bot`).
- **AIMD adaptive rate limiter** per bot discovers Telegram's real ceiling by
  reacting to 429/`flood_wait` (no manual ceiling).
- **Consistent hashing** (SHA-256, 160 virtual nodes) assigns users to stable
  helpers when the fleet enters peak mode.
- **Fleet manager** in every instance: SETNX leader election, peak/off-peak
  state machine with Redis pub/sub broadcast + polling reconcile, heartbeat
  TTLs, batch off-peak migration back to main.

### Transport decision

Bot API over **HTTP/2 persistent connections with keep-alive pooling**
(`internal/telegram/client.go`, `newHTTPClient`, line ~472:
`ForceAttemptHTTP2 = true`, `MaxIdleConnsPerHost = 64`, `MaxIdleConns = 256`,
`IdleConnTimeout = 90s`).

MTProto was explicitly rejected: it is officially unsupported for bots and can
lead to account bans. The Bot API *is* MTProto server-side; for bots the
community-standard equivalent is persistent HTTP/2 + adaptive throttling,
which is what is implemented.

---

## 2. Package Structure

| Package | Responsibility | Key files |
|---|---|---|
| `cmd/miogram` | Wiring & process: config load, Redis/PG connect, limiter+manager construction, webhook HTTP server, worker pool | `main.go` (`main` L31, `webhookHandler` L182, `worker` L233, `isTelegramIP` L299) |
| `internal/config` | All environment parsing + defaults, fleet/AIMD knobs | `config.go` |
| `internal/bot` | Update processing (auth, onboarding, chat relay, profile, admin), Registrar & Resolver logic, peak suggestions | `service.go`, `chat.go`, `auth.go`, `start.go`, `context.go`, `keyboards.go` |
| `internal/telegram` | Bot API transport: outbound job queue per bot, HTTP/2 client, response classification | `client.go`, `types.go` |
| `internal/queue` | Every Redis interaction: queues, routing CAS scripts, pending queue, leader lock, heartbeats, mode/pubsub | `redis.go` |
| `internal/fleet` | Consistent-hashing ring, AIMD limiter, fleet manager (election/modes/migration/sweeper/stats) | `ring.go`, `limiter.go`, `manager.go` |
| `internal/storage` | PostgreSQL (pgx v5): migrations, users/chats/payments queries, durable routing | `store.go`, `models.go`, `migrations.go` |
| `internal/jobs` | Periodic jobs (search expiry, fake-chat lifecycle, cron broadcasts) | `scheduler.go` |
| `internal/payments` | Zarinpal request/verify HTTP handlers | `service.go` |
| `internal/tunnel` | Dev-only Cloudflare Quick Tunnel | `cloudflared.go` |

---

## 3. Core Flows

### 3.1 Inbound (webhook → worker)

```
Telegram ──HTTPS──▶ nginx :443 ──▶ 127.0.0.1:808x  (cmd/miogram main.go L182)
   │ secret-token check, IP allowlist, 2MB body cap
   ▼
EnqueueInboundUnique (Lua: dedup key miogram:update:<update_id> NX PX 24h,
                      then RPUSH inbound:<bot_id>)          queue/redis.go L51
   ▼
worker pool (WORKER_COUNT goroutines) BLPOP inbound:<bot_id> (5s timeout)
   ▼
per-user distributed lock AcquireLock("miogram:userlock:<uid>") → Process()
```

The worker extracts `user_id` from any update type (`updateUserID`,
main.go L272) and passes its own `BOT_ID` into `Process` so every downstream
write knows the source bot.

### 3.2 Registration of user↔bot mapping (Registrar)

`Process` → `afterUserOnline` (bot/service.go L127) → **`registerBotForUser`**
(service.go L244):

1. `queue.RegisterUserBot` (queue/redis.go L104) runs an atomic Lua script
   (`registerUserBotScript`, redis.go L387):
   - `HGET user_bot_routing:<shard> <user_id>`; if already equal to the new
     bot → **return 0, write nothing** (skip-write rule);
   - otherwise `HSET` + `SADD user_bot_reverse:<newbot>` +
     `SREM user_bot_reverse:<oldbot>` atomically.
2. Only when the Lua reported a change (`changed == true`) the service calls
   `routing.UpdateAssignedBot` (PostgreSQL, storage/store.go L124) to mirror
   `users.assigned_bot`. Identical updates therefore cost zero PG writes.

Shard function: `userShard(userID)` = sum of character codes mod 10000
(redis.go L483).

### 3.3 Outbound routing (Resolver)

Every send funnels through `Service.send` (bot/service.go L353):

1. Strip internal `_from_user` marker (never transmitted).
2. Group/negative chat IDs bypass resolution (admin groups etc.).
3. For private recipients call **`resolveDelivery(ctx, userID)`**
   (service.go L269) which implements the three-tier read path:

```
Tier 1  Redis  HGET user_bot_routing:<shard>
Tier 2  PG     SELECT assigned_bot FROM users        (on Redis miss)
          ├── pgx.ErrNoRows → return error ("user does not exist")
          ├── ""            → durable backfill to main (legacy rows)
          └── value         → backfill Redis (CAS) and use it
Health  if resolved helper is inactive (off-peak or dead heartbeat)
          → CAS-move to main in BOTH stores + one-time "moved back" notice
```

4. Same-bot target → `tg.Call`; different bot → `tg.CallViaBot` which pushes
   onto `outbound:<target_bot>`; that instance's consumer delivers.

A resolution error propagates out of `send()` without touching Telegram
(hard-failure rule for non-existent recipients).

### 3.4 Cross-bot delivery cases

| Case | Scenario | Mechanism |
|---|---|---|
| A | Both on same bot | Normal local delivery |
| B | Recipient on other bot, started it | Resolver routes via `outbound:<bot>`; delivered normally |
| C | Recipient moved but never started destination | Response classified `NeedsStart()` (types.go L96: 403 "can't initiate conversation", 400 "chat not found") → `EnqueuePending` parks payload in `pending:<bot>:<user>` + recipient alerted **via the main bot** (cooldown `fleet:startalert:*`) |
| C-timeout | User still hasn't started | Per-instance sweeper (`pendingSweepLoop` → `sweepPending`, manager.go L439) pops stale jobs (> `PENDING_FALLBACK`, default 15m) and retries through the **main bot** (`FallbackDeliverer` wired to `CallViaBot(main)`). `NeedsStart` again → requeue with `Attempts++`; after `PENDING_MAX_ATTEMPTS` (default 4) or permanent failure → drop + notify original sender once (`notifySender`, cooldown `fleet:sendernotice:*`) |
| D | Sender moved, recipient didn't | Resolution always happens at send time using the **recipient's** id, wherever the sender now lives |

Blocked/deactivated users are excluded from pending via
`PermanentlyUndeliverable()` (types.go L116).

Flush trigger: helpers drain a user's list inside `afterUserOnline` when the
CAS reports the mapping changed **or** on explicit `/start`
(crash-recovery path).

### 3.5 AIMD rate limiter

`internal/fleet/limiter.go`. One limiter per bot token guards the single
outbound consumer goroutine (`runOutboundQueue`, telegram/client.go L271).

- Sliding window: timestamps inside trailing 1000 ms; `Acquire` blocks until
  `len(window) < floor(budget)` or the earliest slot expires.
- **Seed**: `AIMD_SEED` (default 20 msg/s).
- **Additive increase**: +`AIMD_INCREMENT` (default 1) at most once per second
  of clean sending. Deliberately **no idle catch-up**: after long silence the
  first tick adds exactly one increment (tested).
- **Multiplicative decrease**: on 429 with `retry_after`, budget ×=
  `AIMD_DECAY` (default 0.5), floored at `AIMD_FLOOR` (default 2); `Penalize`
  returns the server-mandated pause which the transport sleeps verbatim;
  up to 3 attempts per job.
- **No manual ceiling**: `AIMD_MAX=0` (default) disables any cap — the real
  limit is discovered from 429 feedback alone.
- Monitoring surface: `Budget() float64` (current adaptive rate) and
  `Flooded() bool` (true for `retry_after + FLOOD_COOLDOWN`, default 45 s).
  `SetBudgetSource`/`SetFloodSource` feed these into the manager/stats.

### 3.6 Fleet manager

`internal/fleet/manager.go`. Every instance runs one; duties are lease-based:

- **Leader election** (`leaderElectionLoop`, L196): `SET NX PX` on
  `fleet:leader` (lease `LEADER_LEASE`, default 30 s, token-checked renew every
  lease/3 via Lua). Leader crash ⇒ key lapses ⇒ another instance takes over
  within ~one lease. Duties stop immediately on renewal failure.
- **Mode evaluation** (`evaluateMode`, L286): forced `FLEET_MODE=normal|peak`
  short-circuits; otherwise busy = `Flooded()` OR
  `LLEN outbound:main ≥ FLEET_PEAK_QUEUE_LEN` (200). Busy ⇒ peak; quiet for
  `FLEET_OFFPEAK_AFTER` (10 m) and no scheduled window ⇒ off-peak. Schedule
  windows look like `"18-24"` or wrap midnight `"21-02"` (Tehran time).
- **Transitions** (`enterMode`, L523): persist `fleet:mode`, publish
  `{"event":"mode","value":…}` on `fleet:control`; entering off-peak triggers
  batch migration.
- **Followers**: pub/sub subscriber plus `applySharedMode` (L362) poll every
  `MODE_RECONCILE` (10 s) in case a broadcast was missed. Leaders ignore the
  shared key while authoritative.
- **Heartbeats** (`heartbeatLoop`, L147): every `HEARTBEAT_EVERY` (15 s) set
  `fleet:hb:<bot>` with TTL `HEARTBEAT_TTL` (45 s).
- **Consistent hashing ring** (`ring.go`): `AssignHelper(userID)` maps users
  to a stable helper; adding/removing a helper remaps only its arc (~1/N).
- **Peak suggestion** (`SuggestMigration`, L612): deep-link
  `https://t.me/<helper>?start=migrate_<user_id>`; confirmation = the user
  pressing start on the helper (Registrar then flips the mapping).
  Main-only, gated by mode + `fleet:suggest:<uid>` cooldown (`SUGGEST_COOLDOWN`,
  default 6 h) and skipped for active chats.
- **Off-peak consolidation** (`migrateHelpersToMain`, L675): for each helper,
  iterate `SMEMBERS user_bot_reverse:<helper>`; skip chatting users; move the
  rest to main (Redis CAS + durable assign hook); enqueue exactly one
  "return to main" prompt **from the main bot** per moved user.
- **Stats** (`publishStats`, L388): every 10 s HSET
  `fleet:stats:<bot>` {budget, flooded, queue_len, mode, is_leader, ts},
  EXPIRE 60 s.

### 3.7 Active-chat protection

Users whose `users.step` starts with `chatting;` are never disturbed:

1. Peak suggestions skip them (`suggestMigrationIfNeeded`, service.go L425).
2. Off-peak interception on helpers defers the bounce (`bounceToMain` →
   `userIsChatting`, service.go L192/L220) — their next update after end-chat
   performs it.
3. Batch migration skips them via the injected `SetChatFilter` predicate
   (wired to SQL in main.go) and logs a deferred count.

---

## 4. Key Functions & Interfaces

| Function | Purpose | Inputs → Outputs | Called from |
|---|---|---|---|
| `Service.registerBotForUser` (service.go L244) | Registrar write: Redis CAS skip-write + PG mirror on change | ctx, userID, botID → (changed bool, err) | `afterUserOnline` |
| `Service.resolveDelivery` (L269) | Three-tier resolver w/ health fallback | ctx, userID → (botID string, err) | `send`, `handleUndeliverable` |
| `Service.send` (L353) | Routing wrapper around all outgoing API calls | method, params (may carry `_from_user`) → APIResponse, err | everywhere in `internal/bot` |
| `Service.handleUndeliverable` (L384) | Case B parking + alert | userID, fromUserID, method, params, resp | `send` |
| `Service.bounceToMain` (L192) | Off-peak interception on helpers | UpdateContext → err | `Process` |
| `Service.maybeRedirectNewUser` (L501) | New-user redirect during pressure (replaced legacy `ExecuteRedirectLua` load-scores with consistent hashing) | ctx, UpdateContext → handled, err | `handleAuth` |
| `Service.suggestMigrationIfNeeded` (L425) | Peak handoff deep-link w/ cooldown | ctx, UpdateContext | `afterUserOnline` |
| `Service.StartLoadMonitoring` (L473) | Publishes `outbound:<bot>` depth to `bot:loads` zset every second | ctx, Queue | `main.go` |
| `fleet.Limiter.Acquire / Penalize / Flooded / Budget` (limiter.go L64/L102/L125/L132) | AIMD gate / MD+pause / flood query / rate query | see §3.5 | telegram consumer, manager wiring |
| `fleet.Ring.Set / Assign` (ring.go L29/L52) | membership swap / stable assignment | []string ; userID → botID | manager |
| `fleet.Manager.Run` (L135) | starts heartbeats, subscribe, follow, election, stats, sweeper loops | ctx | `main.go` |
| `fleet.Manager.IsActive` (L548) | health gate used by resolver | botID → bool | resolveDelivery |
| `fleet.Manager.AssignHelper` (L568) | consistent-hash assignment | userID → helperID | suggestions, redirect |
| `fleet.Manager.EnqueuePending / DrainPending` (L631/L645) | park undeliverables / atomic flush on start | see signatures | handleUndeliverable / afterUserOnline |
| `fleet.Manager.sweepPending / fallbackDeliver` (L439/L470) | C-timeout retry via main, drop+notify sender | botID | pendingSweepLoop |
| `fleet.Manager.migrateHelpersToMain` (L675) | off-peak batch move w/ chat filter + durable hook | ctx | enterMode(offpeak) |
| `fleet.Manager.evaluateMode` (L286) | forced/busy/quiet state machine | ctx → keepLeading bool | runLeaderDuties |
| `queue.RegisterUserBot / MoveUserBot` (redis.go L104/L118) | atomic CAS routing writes incl. reverse index | userID, botID → changed | registrar, resolver, migration |
| `queue.TakePending / PopOldestPending / RepushPending` (L218/L247/L267) | atomic drain-all (start flush) / pop-one (sweeper) / requeue | see signatures | DrainPending, sweeper |
| `queue.TryLeaderLock / RenewLeaderLock / ReleaseLeaderLock` (L295/L300/L309) | SETNX lease primitives | token, lease | leaderElectionLoop |
| `telegram.Client.Call / CallViaBot` (client.go L84/L90) | queued API call on own/other bot's queue | method, params → APIResponse, err | Service.send |
| `telegram.EnqueueOutbound` (L209) | fire-and-forget push to another bot's queue (notifications) | rdb, botID, method, params | manager notices |
| `telegram.APIResponse.NeedsStart / PermanentlyUndeliverable` (types.go L96/L116) | error classification driving Case B/C | receiver → bool | handleUndeliverable, sweeper |
| `storage.Store.AssignedBot / UpdateAssignedBot` (store.go L111/L124) | durable routing tier | see signatures | resolver, registrar |

Renamed/removed symbols you may meet in older docs:
`getBotForUser` → superseded by `resolveDelivery`;
`ExecuteRedirectLua` (+`redirectLuaScript`) → removed; replaced by the hash
ring (`AssignHelper`).

---

## 5. Environment Variables

Defaults live in `internal/config/config.go`; example files `.env.main`,
`.env.shard1..5`.

| Variable | Default | Description | main recommended | helper recommended |
|---|---|---|---|---|
| `APP_ADDR` | `:8080` | HTTP listen address (compose maps host ports) | `:8080` | `:8080` (mapped 8081-85) |
| `PUBLIC_BASE_URL` | – | Public HTTPS base for webhooks/pay links | your domain | same domain |
| `IS_DEVELOP` | false | Cloudflare Quick Tunnel dev mode | false | false |
| `BOT_ID` | `main` | This instance's fleet id | `main` | `shardN` |
| `BOT_TOKEN` | required | BotFather token | main token | shardN token |
| `BOT_USERNAME` | `full_chat_bot` | t.me username (deep-links) | main username | shardN username |
| `BOT_NAME` | `اسم ربات` | Display name | – | – |
| `WEBHOOK_PATH` | `/bot/user/index.php` | Webhook route | `/bot/main` | `/bot/shardN` |
| `WEBHOOK_SECRET` | "" | Secret-token header (**required in prod**) | strong random | strong random |
| `VERIFY_TELEGRAM_IP` | true | Allowlist Telegram CIDRs (auto-off in develop) | true | true |
| `SET_WEBHOOK_ON_START` | false | Register webhook at boot | true | true |
| `ADMIN_ID` | `71983499` | Admin numeric id | yours | yours |
| `MERCHANT_ID` | "" | Zarinpal merchant | yours | – |
| `PAYMENT_GATEWAY` | `zarinpal` | Gateway selector | zarinpal | zarinpal |
| `DATABASE_URL` | localhost DSN | PostgreSQL DSN | compose DSN | compose DSN |
| `REDIS_ADDR/PASSWORD/DB` | localhost/""/0 | Shared Redis (same DB for all instances!) | redis:6379 | redis:6379 |
| `UPDATE_QUEUE_KEY` | `miogram:telegram:updates` | Legacy global queue (unused by fleet flow) | default | default |
| `WORKER_COUNT` | 16 | Inbound workers per instance | 16 | 16 |
| `FILES_DIR` | `bot/files` | Static assets dir | default | default |
| `HTTP_TIMEOUT` | 10s | Telegram HTTP timeout | 10s | 10s |
| `JOB_INTERVAL` | 60s | Scheduler cadence | 60s | 60s |
| `DB_MAX_CONNS` | 40 | pgx pool size | 40 | 40 |
| `PER_USER_LOCK_TTL/WAIT` | 30s/15s | Per-user processing lock | defaults | defaults |
| `TELEGRAM_SOCKS5_PROXY` | "" | socks5:// proxy (optional) | – | – |
| `CLOUDFLARED_PATH` | `cloudflared` | Dev tunnel binary | – | – |
| `DEVELOP_TUNNEL_TIMEOUT` | 45s | Tunnel startup wait | – | – |
| `FLEET_MAIN_BOT` | `main` | Fallback/consolidation target | `main` | `main` |
| `FLEET_HELPERS` | "" | `id=@username,…` helper registry | full list | full list |
| `FLEET_MODE` | `auto` | `auto`/`normal`/`peak` override | auto | auto |
| `FLEET_PEAK_HOURS` | "" | e.g. `18-24`, wraps `21-02`; empty = reactive | optional | optional |
| `FLEET_PEAK_QUEUE_LEN` | 200 | main queue depth ⇒ peak | 200 | 200 |
| `FLEET_OFFPEAK_AFTER` | 10m | sustained quiet before downgrade | 10m | 10m |
| `FLEET_MIGRATION_NOTIFY` | true | Return-to-main prompts | true | true |
| `AIMD_SEED` | 20 | starting msg/s | 20 | 20 |
| `AIMD_FLOOR` | 2 | post-decay floor | 2 | 2 |
| `AIMD_INCREMENT` | 1 | additive step / clean second | 1 | 1 |
| `AIMD_DECAY` | 0.5 | multiplier on flood_wait | 0.5 | 0.5 |
| `AIMD_MAX` | 0 | hard cap; **0 = none (discovered)** | 0 | 0 |
| `FLOOD_COOLDOWN` | 45s | growth pause + flooded flag window | 45s | 45s |
| `PENDING_TTL` | 48h | pending list/index TTL | 48h | 48h |
| `PENDING_FALLBACK` | 15m | age before main-bot retry | 15m | 15m |
| `PENDING_MAX_ATTEMPTS` | 4 | retries before drop+sender-notice | 4 | 4 |
| `LEADER_LEASE` | 30s | leadership lease TTL | 30s | 30s |
| `HEARTBEAT_TTL/EVERY` | 45s/15s | liveness key | defaults | defaults |
| `MODE_RECONCILE` | 10s | shared-mode poll cadence | 10s | 10s |
| `SUGGEST_COOLDOWN` | 6h | per-user suggest/notice cooldowns | 6h | 6h |

---

## 6. Redis Data Structures

| Key | Type | TTL | Purpose |
|---|---|---|---|
| `user_bot_routing:<shard>` (shard = charsum%10000) | hash | – | hot user→bot map |
| `user_bot_reverse:<bot>` | set | – | reverse index for batch migration |
| `inbound:<bot>` | list | – | raw webhook updates for this bot |
| `outbound:<bot>` | list | 24h (refreshed) | API jobs; single consumer per bot applies throttling |
| `miogram:update:<update_id>` | string | 24h | webhook dedup (Lua NX) |
| `miogram:telegram:response:<jobid>` | list | 5m | RPC reply for queued API call |
| `pending:<bot>:<user>` | list | 48h | parked messages awaiting `/start` |
| `pending:index:<bot>` | set | 48h | users with parked messages (sweeper input) |
| `fleet:mode` | string | – | `peak`/`offpeak` shared state |
| `fleet:control` | pub/sub ch | – | instant mode broadcast |
| `fleet:leader` | string | 30s lease | leader election (token-checked renew/release) |
| `fleet:hb:<bot>` | string | 45s | liveness heartbeat |
| `fleet:stats:<bot>` | hash | 60s | budget/flooded/queue_len/mode/is_leader/ts |
| `bot:loads` | zset | – | ops visibility of queue depths (`StartLoadMonitoring`) |
| `fleet:suggest:<u>`, `fleet:startalert:<b>:<u>`, `fleet:movednotice:<u>`, `fleet:sendernotice:<u>` | string | 6h | anti-spam cooldowns |
| `miogram:userlock:<u>` | string | 30s | per-user processing lock |

Atomic Lua scripts (queue/redis.go): `registerUserBotScript` (L387, CAS +
reverse index maintenance), `takePendingScript` (L404, drain-all + index
clean), `popOldestPendingScript` (L415, FIFO pop-one), `enqueueUniqueScript`
(~L370, dedup+push), `releaseScript` (L379) and `renewLeaderScript`/
`releaseLeaderScript` (~L430+, token-checked leader lease ops).

Note: go-redis decodes Lua bulk arrays as `[]interface{}` — `TakePending`
coerces explicitly (a former bug caught by tests).

---

## 7. Debugging Guide

### Where is my message?

```bash
# 1. Did the webhook arrive / is the inbound backlog growing?
LLEN inbound:main           # per bot; workers BLPOP these
LLEN outbound:main          # API jobs waiting for THIS bot's consumer

# 2. Which bot owns sender/recipient? (compute shard first)
#    shard = (sum of ASCII codes of user_id digits) % 10000
HGET user_bot_routing:<shard> <user_id>

# 3. Was it parked because the recipient never started the destination bot?
SMEMBERS pending:index:shard1
LRANGE pending:shard1:12345 0 -1        # inspect payloads + attempts/ts

# 4. Fleet state at a glance
GET fleet:mode
GET fleet:leader                        # who leads (value = random token)
TTL fleet:hb:shard1                     # <=45000 means alive
HGETALL fleet:stats:main                # budget/flooded/queue_len/is_leader
ZRANGE bot:loads 0 -1 WITHSCORES        # historical load scores
```

### Common issues → actions

| Symptom | Likely cause | Fix / check |
|---|---|---|
| Message stuck in `pending:*` | Recipient never started destination helper | They must open `t.me/<helper>?start=migrate_<id>`; flush happens on next update there. Sweeper will retry via main after `PENDING_FALLBACK`, then drop+notify sender after `PENDING_MAX_ATTEMPTS` |
| Sudden throughput collapse on one bot | AIMD decayed after 429 storm | Watch `HGET fleet:stats:<bot> budget` — recovers +1/s while clean; verify nothing else shares the bot token |
| Helper considered dead | Heartbeat lapsed (crash, GC pause, clock) | `EXISTS fleet:hb:shard1`; resolver auto-falls back to main meanwhile |
| Two leaders claimed | Lease expired mid-freeze; tokens differ | Harmless transient — `GET fleet:leader` shows current holder; losers stand down on next renewal failure |
| Mode stuck in peak | Busy signal present (flooded flag or `LLEN outbound:main ≥ 200`) or scheduled window active | Check `flooded` field + queue length; clear schedule `FLEET_PEAK_HOURS=` or force `FLEET_MODE=offpeak`→`auto` |
| Duplicate-looking sends | None expected — drains are atomic | Verify with `LRANGE pending:...` before assuming; drains delete atomically (see tests) |
| Updates processed twice | Dedup key expired (>24h replay) | Rare; Telegram guarantees at-least-once only |

Verifying AIMD live: watch `fleet:stats:<bot>.budget` climb ~+1/s under steady
traffic, halve instantly on a forced 429, and stay flat during the cooldown
window. Verifying fleet transitions: subscribe `SUBSCRIBE fleet:control` while
flipping signals.

---

## 8. Testing & Validation

```bash
gofmt -l .                 # formatting
go build ./...
go vet ./...
go test -race -count=1 ./internal/fleet/... ./internal/queue/... \
                          ./internal/bot/... ./internal/telegram/...
go test -count=1 ./...
```

Test categories (all green at time of writing, 64 tests):

- **AIMD** (mock clock): seed, additive increase, multiplicative decrease,
  floor clamp, cooldown freeze, no idle catch-up, exact retry_after passthrough,
  optional cap, concurrent acquire, context cancellation.
- **Ring**: stickiness, minimal remap on add/remove, fair distribution,
  empty-ring behavior.
- **Election/state machine**: two-instance competition, crash takeover inside
  lease, exactly-one-leader, pub/sub broadcast assertion, forced overrides,
  busy/quiet transitions, missed-broadcast reconcile.
- **Cross-bot scenarios** (miniredis + stub deliverer): B/C parking, timeout
  retry-via-main, NeedsStart requeue w/ Attempts++, permanent drop + sender
  notification landing on `outbound:main`.
- **Pending races**: 8 consumers × 60 messages drained exactly-once; reverse
  index consistency under 16 racing writers; skip-write idempotence.
- **Off-peak consolidation**: chatting-user deferral, single notification per
  moved user, durable-mirror calls limited to actual movers.
- **Transport e2e**: scripted `http.RoundTripper` returns 429 then success
  through the REAL Redis pipeline; asserts `Penalize(retry_after)` called and
  delivery succeeds on attempt 2.
- **Resolver matrix** (fake PG backend): Redis hit/miss, PG hit/backfill,
  ErrNoRows hard error, legacy empty backfill, both-store fallback persistence.

Tooling: `github.com/alicebob/miniredis/v2` executes the actual Lua scripts in
tests; Telegram is simulated via injectable `Throttler` interface and mock
RoundTrippers — no network needed.

---

## 9. Deployment & Security Considerations

- **Containers**: current Dockerfile has no `USER` directive — add a non-root
  user before exposing publicly.
- **Secrets**: everything comes from env (`BOT_TOKEN`, `WEBHOOK_SECRET`,
  `MERCHANT_ID`, DB/Redis URLs). Never commit real values; the shipped
  `.env.*` files contain placeholders only. Keep `*.env*` gitignored and audit
  with `git ls-files | grep env`.
- **Webhook**: always set a strong `WEBHOOK_SECRET` (the check fails OPEN when
  empty) and leave `VERIFY_TELEGRAM_IP=true` behind nginx that preserves
  `X-Forwarded-For`.
- **Scanning**: `govulncheck ./...` and `go list -m -u all` in CI.
- **Graceful shutdown**: SIGTERM/SIGINT → http server drains (20s) → worker
  WaitGroup joins. Pending/outbound work persists in Redis, so restarts do not
  lose queued deliveries; only the API call in flight at cancel time is lost
  (caller receives a timeout-class error).
- **Monitoring**: scrape/inspect `fleet:stats:<bot>` (60s TTL snapshots),
  `fleet:hb:<bot>` presence, `GET fleet:mode`, `LLEN outbound:<bot>` /
  `inbound:<bot>`. Suggested alerts: stats key missing >90s, `flooded=true`
  >10m, inbound length trend, pending index growth, leader key absent while
  instances run. `/healthz` answers `ok` (liveness only).

---

## 10. Reference Map

| Topic | File : approx. line |
|---|---|
| Webhook intake, auth, dedup | cmd/miogram/main.go L182–230 |
| Worker loop + per-user lock | cmd/miogram/main.go L233–270 |
| Fleet/limiter wiring | cmd/miogram/main.go L60–110 |
| Registrar write chain | internal/bot/service.go L127–150, L244–264 |
| Resolver three-tier read | internal/bot/service.go L269–338 |
| Send routing + Case B parking | internal/bot/service.go L353–420 |
| Off-peak bounce / chat guard | internal/bot/service.go L192–228 |
| Peak suggestion | internal/bot/service.go L425–448 |
| New-user redirect | internal/bot/service.go L501–527 |
| AIMD controller | internal/fleet/limiter.go (whole file) |
| Hash ring | internal/fleet/ring.go (whole file) |
| Election / modes / migration / sweeper | internal/fleet/manager.go L135–560, L675 |
| Routing + pending + lease Lua | internal/queue/redis.go L104–330, L379–441 |
| Transport, h2 pooling, classification | internal/telegram/client.go L47–120, L209, L271–340, L472 |
| Error classifiers | internal/telegram/types.go L96–130 |
| Durable routing tier | internal/storage/store.go L111–129 |
| Migration adding assigned_bot | internal/storage/migrations.go L66 |
