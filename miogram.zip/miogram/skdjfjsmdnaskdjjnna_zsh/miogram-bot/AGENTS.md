# Repository Guidelines

## Project Structure & Module Organization

This repository contains a Go Telegram bot built around a webhook-to-Redis-queue worker flow. The executable entry point is `cmd/miogram/main.go`. Application code lives under `internal/`: `bot/` handles updates and conversations, `telegram/` wraps the Bot API, `storage/` owns PostgreSQL models and migrations, `queue/` manages Redis, `payments/` handles gateways, `jobs/` runs scheduled work, and `config/` loads environment settings. Static images are in `bot/files/`. Container setup is defined by `Dockerfile` and `docker-compose.yml`.

## Build, Test, and Development Commands

- `cp .env.example .env` creates local configuration; replace all example credentials before use.
- `go run ./cmd/miogram` runs the bot locally and requires reachable PostgreSQL and Redis services.
- `go build -o miogram ./cmd/miogram` produces the local binary.
- `docker compose up -d --build` builds and starts the bot, PostgreSQL, and Redis.
- `docker compose logs -f app` follows application logs; `GET /healthz` checks service health.
- `go test ./...` runs all package tests. Add tests with behavior changes.
- `go vet ./...` performs standard static analysis.

## Coding Style & Naming Conventions

Use standard Go formatting and idioms. Run `gofmt -w .` before committing. Package names and filenames should be short lowercase words; exported identifiers use `PascalCase`, unexported identifiers use `camelCase`, and tests use `TestName`. Keep Telegram transport, persistence, and business logic in their existing packages. Pass `context.Context` through network and database operations, wrap errors with useful context, and avoid logging tokens or user-sensitive data.

## Testing Guidelines

The repository currently has no committed `_test.go` files or explicit coverage gate. Place unit tests beside the code they exercise, named `*_test.go`, and prefer table-driven cases for parsers, handlers, and configuration helpers. Mock external Telegram/payment calls; integration tests must clearly document PostgreSQL and Redis prerequisites. Before opening a PR, run `go test ./...` and `go vet ./...`.

## Commit & Pull Request Guidelines

Git history is unavailable in this checkout, so use concise, imperative commit subjects such as `fix: prevent duplicate webhook updates`. Keep commits focused. Pull requests should explain the user-visible change, configuration or migration impact, and verification performed; link relevant issues and include screenshots when bot messages or media change.

## Security & Configuration

Never commit `.env`, bot tokens, webhook secrets, merchant credentials, or production database URLs. Keep `.env.example` limited to safe placeholders. Use `IS_DEVELOP=true` and Cloudflare Quick Tunnel only for local testing; production requires a stable HTTPS endpoint and a strong `WEBHOOK_SECRET`.
