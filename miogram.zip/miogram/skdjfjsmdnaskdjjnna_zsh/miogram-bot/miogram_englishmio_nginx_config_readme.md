step zero:
sudo apt update
sudo apt install nginx -y

step one:
paste it to this file:
	sudo nano /etc/nginx/sites-available/miogram



# ============================================================
# Miogram (فارسی) — 6 ربات : 8080 تا 8085
# ============================================================
server {
    listen 80;
    listen [::]:80;
    server_name miogram.yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

# ============================================================
# English Miogram (انگلیسی) — 6 ربات : 8090 تا 8095
# ============================================================
server {
    listen 80;
    listen [::]:80;
    server_name english_miogram.yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}






















step1.5:
check that these directories are there?:
	ls -ld /etc/nginx/sites-available /etc/nginx/sites-enabled
step2:
	sudo ln -s /etc/nginx/sites-available/miogram /etc/nginx/sites-enabled/


step3:
delete default config:
	sudo rm /etc/nginx/sites-enabled/default


step4: 
tasting nginx:
	sudo nginx -t

step 4.5:
before geting ca we should check that these URLs are there?
	ping miogram.yourdomain.com
	ping english_miogram.yourdomain.com
step 4.6:
	sudo apt update
	sudo apt install certbot python3-certbot-nginx -y


step5: 
sign ssh Let's encryption:
	sudo certbot --nginx -d miogram.yourdomain.com -d english_miogram.yourdomain.com


step 5.5:

		sudo nano /etc/nginx/sites-available/miogram

# ============================================================
# Miogram (فارسی) — 6 ربات : 8080 تا 8085
# ============================================================
server {
    listen 80;
    listen [::]:80;
    server_name miogram.yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name miogram.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/miogram.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/miogram.yourdomain.com/privkey.pem;

    ssl_protocols        TLSv1.2 TLSv1.3;
    ssl_ciphers          ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
    ssl_prefer_server_ciphers off;

    client_max_body_size 20m;

    proxy_http_version                 1.1;
    proxy_set_header Host              $host;
    proxy_set_header X-Real-IP         $remote_addr;
    proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header Connection        "";

    proxy_connect_timeout              5s;
    proxy_send_timeout                 15s;
    proxy_read_timeout                 15s;

    # Webhook ها
    location /bot/main   { proxy_pass http://127.0.0.1:8080; }
    location /bot/shard1 { proxy_pass http://127.0.0.1:8081; }
    location /bot/shard2 { proxy_pass http://127.0.0.1:8082; }
    location /bot/shard3 { proxy_pass http://127.0.0.1:8083; }
    location /bot/shard4 { proxy_pass http://127.0.0.1:8084; }
    location /bot/shard5 { proxy_pass http://127.0.0.1:8085; }

    # پرداخت و فایل‌ها
    location /pay/ {
        proxy_pass http://127.0.0.1:8080;
    }

    location /files/ {
        proxy_pass http://127.0.0.1:8080;
        expires 7d;
        add_header Cache-Control "public, max-age=604800, immutable";
    }

    location = /healthz {
        proxy_pass http://127.0.0.1:8080;
        access_log off;
    }
}

# ============================================================
# English Miogram (انگلیسی) — 6 ربات : 8090 تا 8095
# ============================================================
server {
    listen 80;
    listen [::]:80;
    server_name english_miogram.yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name english_miogram.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/english_miogram.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/english_miogram.yourdomain.com/privkey.pem;

    ssl_protocols        TLSv1.2 TLSv1.3;
    ssl_ciphers          ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
    ssl_prefer_server_ciphers off;

    client_max_body_size 20m;

    proxy_http_version                 1.1;
    proxy_set_header Host              $host;
    proxy_set_header X-Real-IP         $remote_addr;
    proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header Connection        "";

    proxy_connect_timeout              5s;
    proxy_send_timeout                 15s;
    proxy_read_timeout                 15s;

    # Webhook ها
    location /bot/main   { proxy_pass http://127.0.0.1:8090; }
    location /bot/shard1 { proxy_pass http://127.0.0.1:8091; }
    location /bot/shard2 { proxy_pass http://127.0.0.1:8092; }
    location /bot/shard3 { proxy_pass http://127.0.0.1:8093; }
    location /bot/shard4 { proxy_pass http://127.0.0.1:8094; }
    location /bot/shard5 { proxy_pass http://127.0.0.1:8095; }

    # پرداخت و فایل‌ها
    location /pay/ {
        proxy_pass http://127.0.0.1:8090;
    }

    location /files/ {
        proxy_pass http://127.0.0.1:8090;
        expires 7d;
        add_header Cache-Control "public, max-age=604800, immutable";
    }

    location = /healthz {
        proxy_pass http://127.0.0.1:8090;
        access_log off;
    }
}


step6:
reload and testing nginx:
	sudo nginx -t
	sudo systemctl reload nginx